package raulcastilla215alu.matrix;

@SuppressWarnings("serial")
public class HeaderException extends Exception{
	
	public HeaderException(String msg) {
		super(msg);
	}
}
