package raulcastilla215alu.matrix;

@SuppressWarnings("serial")
public class SizeException extends Exception{

	public SizeException(String msg) {
		super(msg);
	}
}
